@echo off
chcp 65001 >nul
title Kickoff du midi - desinstallation de l'agent
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'powershell.exe' -and $_.CommandLine -like '*kickoff-agent.ps1*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }" >nul 2>&1
del /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\KickoffDuMidi.vbs" 2>nul
del /Q "%APPDATA%\KickoffDuMidi\kickoff-agent.ps1" 2>nul
echo.
echo  L'agent Kickoff du midi est arrete et ne se lancera plus au demarrage.
echo  Tes matchs restent dans %APPDATA%\KickoffDuMidi\matchs.json (supprime le dossier pour tout effacer).
echo.
pause
