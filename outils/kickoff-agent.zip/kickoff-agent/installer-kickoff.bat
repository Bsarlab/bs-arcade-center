@echo off
chcp 65001 >nul
title Kickoff du midi - installation de l'agent
set "DOSSIER=%APPDATA%\KickoffDuMidi"
set "DEMARRAGE=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
echo.
echo  KICKOFF DU MIDI - installation de l'agent
echo  -----------------------------------------
if not exist "%~dp0kickoff-agent.ps1" (
  echo  Le fichier kickoff-agent.ps1 est introuvable.
  echo  Decompresse tout le zip dans un dossier, puis relance ce fichier.
  pause
  exit /b 1
)
mkdir "%DOSSIER%" 2>nul
rem Arrete une ancienne version si elle tourne
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'powershell.exe' -and $_.CommandLine -like '*kickoff-agent.ps1*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }" >nul 2>&1
copy /Y "%~dp0kickoff-agent.ps1" "%DOSSIER%\kickoff-agent.ps1" >nul
powershell -NoProfile -Command "Unblock-File -Path '%DOSSIER%\kickoff-agent.ps1'" >nul 2>&1
> "%DEMARRAGE%\KickoffDuMidi.vbs" echo CreateObject("WScript.Shell").Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""%DOSSIER%\kickoff-agent.ps1""", 0, False
start "" wscript.exe "%DEMARRAGE%\KickoffDuMidi.vbs"
echo.
echo  C'est installe !
echo  - L'agent tourne maintenant en arriere-plan (aucune fenetre).
echo  - Il se relancera tout seul a chaque demarrage de Windows.
echo  - Pour verifier : ouvre http://localhost:49125/etat dans ton navigateur.
echo.
pause
